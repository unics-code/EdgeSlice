#!/bin/bash

python2.7 python/darknet.py
