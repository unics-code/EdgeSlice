#!/bin/bash

python2.7 python/collect_dataset.py
